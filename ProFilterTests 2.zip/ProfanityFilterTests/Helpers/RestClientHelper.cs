using RestSharp;
using Newtonsoft.Json.Linq;

namespace ProfanityFilterTests.Helpers
{
    public class RestClientHelper
    {
        private const string BaseUrl = "http://www.purgomalum.com/service";


    public string FilterProfanity(string text)
{
    if (string.IsNullOrEmpty(text))
    {
        return string.Empty;  // Immediately return empty if input is empty
    }

    var client = new RestClient(BaseUrl);
    var request = new RestRequest("/json", Method.Get);
    request.AddQueryParameter("text", text);


    var response = client.Execute(request);
    if (response.IsSuccessful)
    {
        var json = JObject.Parse(response.Content);
        return json["result"]?.ToString() ?? json["error"]?.ToString() ?? string.Empty;  // Also handle "error" field
    }
    return string.Empty;
}
    }
}
