using RestSharp;
using NUnit.Framework;
using ProfanityFilterTests.Helpers;
using TechTalk.SpecFlow;

namespace ProfanityFilterTests.StepDefinitions
{
    [Binding]
    public class ProfanityFilterSteps
    {
        private string _inputText;
        private string _apiResponse;
        private readonly RestClientHelper _restClientHelper;

        public ProfanityFilterSteps()
        {
            _restClientHelper = new RestClientHelper();
        }

        [Given(@"I have a text ""(.*)""")]
        public void GivenIHaveAText(string text)
        {
            _inputText = text;
        }

        [When(@"I call the profanity filter API")]
        public void WhenICallTheProfanityFilterAPI()
        {
            _apiResponse = _restClientHelper.FilterProfanity(_inputText);
        }

        [Then(@"the response should return ""(.*)""")]
        public void ThenTheResponseShouldReturn(string expectedResponse)
        {
            Assert.AreEqual(expectedResponse, _apiResponse);
        }
    }
}
