using NUnit.Framework;
using ProfanityFilterTests.Helpers;

namespace ProfanityFilterTests.Tests
{
    [TestFixture]
    public class ProfanityFilterTests
    {
        [Test]
        public void FilterProfanity_ShouldReturnCensoredText()
        {
            var helper = new RestClientHelper();
            var result = helper.FilterProfanity("This is a gook test");

            Assert.AreEqual("This is a **** test", result);
        }

        [Test]
        public void FilterProfanity_WithEmptyText_ShouldReturnEmptyString()
        {
            var helper = new RestClientHelper();
            var result = helper.FilterProfanity(string.Empty);

            Assert.AreEqual(string.Empty, result);
        }
    }
}
